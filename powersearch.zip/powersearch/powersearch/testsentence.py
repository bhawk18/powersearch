import nltk
import re
sentence = """How many logs from Cisco?"""
tokens = nltk.word_tokenize(sentence)
tagged = nltk.pos_tag(tokens)
#entities = nltk.chunk.ne_chunk(tagged)

def properword(improttree):

    Productfinal=[]
    for i in improttree:
        m = re.match('\w+',i)
        Productfinal.append((m.group(0)))
    #print Productfinal
    return Productfinal
s = "(S (ques how/WRB) (count many/JJ) (B-tags login/NN) (source from/IN) the/DT (B-Product fortigate/NN) (I-product firewall/NN)  ?/.)"

from nltk.tree import Tree

entities=Tree.fromstring(s)
#print type(entities)
def parsering(entities):
    #entitiesd = Tree.fromstring(entities)
    #print entitiesd
    Product = []
    User_name = []
    Tag = []
    Source = []

    for chunk in entities:
    #print chunk
        if type(chunk) == nltk.tree.Tree:
        #print chunk.label()
            if chunk.label() == 'B-Product' or chunk.label() == "I-product" or chunk.label()== "B-product":
                Product.append(' '.join([c[0] for c in chunk]))
            elif chunk.label() == 'B-name' or chunk.label() == 'I-name' or chunk.label() == 'B-Name':
                User_name.append(''.join([c[0] for c in chunk]))
            elif chunk.label() == 'B-tags' or chunk.label() == 'I-tags' or chunk.label() =='B-Tag' or chunk.label()=='B-tag' or chunk.label()=='I-tag' or chunk.label() == 'B-tag' or chunk.label() == 'Tag':
                Tag.append(' '.join([c[0] for c in chunk]))
            elif chunk.label() =='source':
                Source.append(''.join([c[0] for c in chunk]))

    #print Product
    #return properword(Product)

    #print Tag

    #return properword(Tag)

    #print(User_name)
    #return properword(User_name)

    #print Source
    #return properword(Source)
    if Tag and Product and User_name:
        return ["tag:( "+" ".join(properword(Product))+" AND "+" ".join(properword(Tag))+")"+"src_user_name:"+" ".join(properword(User_name))]
    elif Tag:
        return ["tag:( "+" ".join(properword(Product))+" AND "+" ".join(properword(Tag))+")"]
    elif User_name:
        return ["src_user_name:" + " ".join(properword(User_name))]
    elif Tag and User_name:
        return ["tag:( " + " ".join(properword(Product)) + " AND " + " ".join(
            properword(Tag)) + ")" + "src_user_name:" + " ".join(properword(User_name))]
    """
    else:
        return ["tag:( "+" ".join(properword(Product))+"and"+" ".join(properword(Tag))+")"+"src_user_name:"+" ".join(properword(User_name))]

#query = "tag:"+(properword(Tag))+"Product"+(properword(Product))

"""