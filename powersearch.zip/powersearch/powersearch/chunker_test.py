from nltk import pos_tag, word_tokenize
import pickle
classifier_f = open("entitychunker.pickle", "rb")
chunker = pickle.load(classifier_f)
classifier_f.close()
print chunker(pos_tag(word_tokenize("how many logs from cisco today?")))

