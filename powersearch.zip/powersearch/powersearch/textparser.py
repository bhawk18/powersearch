import pickle
from nltk import word_tokenize
def features(sentence, index):
    """ sentence: [w1, w2, ...], index: the index of the word """
    return {
        'word': sentence[index],
        'is_first': index == 0,
        'is_last': index == len(sentence) - 1,
        'is_capitalized': sentence[index][0].upper() == sentence[index][0],
        'is_all_caps': sentence[index].upper() == sentence[index],
        'is_all_lower': sentence[index].lower() == sentence[index],
        'prefix-1': sentence[index][0],
        'prefix-2': sentence[index][:2],
        'prefix-3': sentence[index][:3],
        'suffix-1': sentence[index][-1],
        'suffix-2': sentence[index][-2:],
        'suffix-3': sentence[index][-3:],
        'prev_word': '' if index == 0 else sentence[index - 1],
        'next_word': '' if index == len(sentence) - 1 else sentence[index + 1],
        'has_hyphen': '-' in sentence[index],
        'is_numeric': sentence[index].isdigit(),
        'capitals_inside': sentence[index][1:].lower() != sentence[index][1:]
    }
classifier_f = open("E:\powersearch\\naivebayes.pickle", "rb")
clf = pickle.load(classifier_f)
classifier_f.close()

def poss_tag(sentence):
    tagged_sentence = []
    tags = clf.predict([features(sentence, index) for index in range(len(sentence))])
    return zip(sentence, tags)

f = open('E:\powersearch\\trainner.tags', 'r')

raw = f.readlines()

for line in raw:
 #print line
 f2=open('E:\powersearch\\trainnerparser.txt', 'a')
 f2.write("\n\n")
 f2.close()
 tokens = word_tokenize(line)
 data=poss_tag(tokens)
 #print data
 #print data
 for x,y in data:
  f2=open('E:\powersearch\\trainnerparser.txt', 'a')
  f2.write(x + ' ' + y + "\n")
  #print "done line 1"
  f2.close()
print 'done writing'
