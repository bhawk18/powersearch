import nltk
sentence = """At eight o'clock on Thursday morning Arthur didn't feel very good."""
tokens = nltk.word_tokenize(sentence)
tagged = nltk.pos_tag(tokens)
entities = nltk.chunk.ne_chunk(tagged)

Product=[]
User_name=[]
Tag = []
Source=[]
print entities
for chunk in entities:
    print chunk
    if type(chunk) == nltk.tree.Tree:
        if chunk.label() == 'B-product' and chunk.label() == "I-product":
            Product.append(' '.join([c[0] for c in chunk]))
        elif chunk.label() == 'B-name' or chunk.label() == 'I-name':
            User_name.append(''.join([c[0]for c in chunk]))
        elif chunk.label() == 'B-tag' and chunk.label() == "I-tag":
            Tag.append(' '.join([c[0] for c in chunk]))
        elif chunk.label() =='source':
            Source.append(''.join([c[0]for c in chunk]))


if Source == "from" or "in"
    usercim="src_user_name"

if Product and User_name and Tag:
    print "tags:"+Product+Tag+"AND"+usercim+":"+User_name"
elif Product and User_name:
    print "tags:"+Product+"AND"+usercim+":"+User_name
elif Tag :
    print "tags:"+Tag



