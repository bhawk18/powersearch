from nltk.chunk import conlltags2tree, tree2conlltags
import nltk
data="""(S
  (ques how/WRB)
  (count many/JJ)
  logs/NNS
  ( from/IN)
  (B-product cisco/NN)
  (I-product today/NN)
  ?/.)"""


#print data

print type(data)
""""
places = []
for ne in data:
    print ne           #if type(ne) is nltk.tree.Tree:
               # print ne
               # if (ne.label() == 'B-product' or ne.label() == 'I-product' or ne.label() == 'B-Tag' or ne.label() == 'I-Tag'):
                 #   places.append(u' '.join([i[0] for i in ne.leaves()]))
print places

"""
